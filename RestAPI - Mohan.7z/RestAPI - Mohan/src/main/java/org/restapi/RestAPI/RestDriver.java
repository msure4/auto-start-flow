package org.restapi.RestAPI;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.client.ClientProtocolException;
import org.restapi.startstopflow.CreatePutObjectAndExecute;
import org.xml.sax.SAXException;

public class RestDriver {

	public static final String startStopURI = "/nifi-api/flow/process-groups/%s";

	public static final String startState = "RUNNING";
	public static final String stopState = "STOPPED";
	public static final String jsonHeader = "application/json";
	public static final String allTypeHeader = "*/*";

	public static CreatePutObjectAndExecute startStopObj = new CreatePutObjectAndExecute();

	public static void main(String[] args)
			throws ClientProtocolException, IOException, SAXException, ParserConfigurationException {
		// TODO Auto-generated method stub
		
		String hostUrl = null;
		String portNumber = null;
		String action = null;
		String processGroupId = null;

		if (args.length < 4) {
			System.out.println("Invalid arguments");
			System.out.println("Usage : jarName URL PORT Action-START/STOP UUID");
			System.exit(1);
		}

		else {
			 hostUrl = args[0];
			 portNumber = args[1];
			 action = args[2].toUpperCase();
			 processGroupId = args[3];
		}

		/* hostUrl = "localhost";
		 portNumber = "8080";
		 action = "start".toUpperCase();
		 processGroupId = "48123632-4179-340b-35bb-a1dac14af77d" ; 	*/
		String nifiURL = "http://" + hostUrl + ":" + portNumber;

		switch (action) {
		case "START":
		case "STOP":
			startStopObj.startFlowMethod(nifiURL, action, processGroupId, RestDriver.startStopURI);
			break;
		}

	}

}
