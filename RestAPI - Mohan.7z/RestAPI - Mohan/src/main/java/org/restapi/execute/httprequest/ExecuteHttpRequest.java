package org.restapi.execute.httprequest;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;

public class ExecuteHttpRequest {

	public HttpResponse executeHttpRequest(HttpUriRequest request) {
		HttpClient httpClient = HttpClientBuilder.create().build();
		HttpResponse httpResponse = null;
		
		try {
			 httpResponse = httpClient.execute(request);
		} 
		catch (ClientProtocolException e) {
			System.out.println("Encountered Protocol Exception "+e);
			e.printStackTrace();
		} 
		catch (IOException e) {
			System.out.println("Encountered IOException "+e);
			e.printStackTrace();

		}
		return httpResponse;
	}
}
