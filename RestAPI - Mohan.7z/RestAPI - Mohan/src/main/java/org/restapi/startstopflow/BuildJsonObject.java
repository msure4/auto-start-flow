package org.restapi.startstopflow;

import org.json.simple.JSONObject;

public class BuildJsonObject {
	
	@SuppressWarnings("unchecked")
	public JSONObject createJSON(String processGroupId, String state) {
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("id", processGroupId);
		jsonObj.put("state", state);
		return jsonObj;
		
	}
	

}
