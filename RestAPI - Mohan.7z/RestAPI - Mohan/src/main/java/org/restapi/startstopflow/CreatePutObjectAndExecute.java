package org.restapi.startstopflow;

import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpPut;
import org.restapi.RestAPI.RestDriver;
import org.restapi.create.httprequest.CreateHttpPutRequest;
import org.restapi.execute.httprequest.ExecuteHttpRequest;

public class CreatePutObjectAndExecute {
	public void startFlowMethod(String nifiURL, String action, String processGroupId, String myUri) {
		String uri = String.format(myUri, processGroupId);
		String hostString = nifiURL + uri;
		
		BuildJsonObject buildJSONObj = new BuildJsonObject();
		String jsonObj = null;

		switch (action) {
		case "START":
			jsonObj = buildJSONObj.createJSON(processGroupId, RestDriver.startState).toJSONString();
			break;
		case "STOP":
			jsonObj = buildJSONObj.createJSON(processGroupId, RestDriver.stopState).toJSONString();
			break;
		}

		CreateHttpPutRequest createReqObj = new CreateHttpPutRequest();
		HttpPut HttpPut = createReqObj.createPutRequest(hostString, jsonObj, RestDriver.jsonHeader);

		ExecuteHttpRequest execObj = new ExecuteHttpRequest();
		HttpResponse response = execObj.executeHttpRequest(HttpPut);

		StatusLine status = response.getStatusLine();
		if (status.getStatusCode() == 200 || status.getStatusCode() == 202)
			System.out.println("Successfully executed the request");
		else
			System.out.println("Execution failed. Please verify input and validity of NiFi Process Group ID");

	}

}
