package org.restapi.create.httprequest;

import org.apache.http.client.methods.HttpGet;

public class CreateHttpGetRequest {
	public HttpGet createHttpGetRequest(String hostURI,String contentType){
		HttpGet httpGet = new HttpGet(hostURI);
		httpGet.addHeader("content-type", contentType);
		return httpGet;
	}

}
