package org.restapi.create.httprequest;

import org.apache.http.client.methods.HttpPost;

public class CreateHttpPostRequest {
	public HttpPost createPostRequest(String hostURI, String contentType) {
		
		HttpPost httpPost = new HttpPost(hostURI);
		httpPost.addHeader("content-type", contentType);
		return httpPost;
		
	}

}
