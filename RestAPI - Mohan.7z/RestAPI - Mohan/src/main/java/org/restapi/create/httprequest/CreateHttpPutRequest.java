package org.restapi.create.httprequest;

import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;

public class CreateHttpPutRequest {
	

	public HttpPut createPutRequest(String hostURI, String jsonObj,String contentType) {
		
		HttpPut httpPut = new HttpPut(hostURI);
		httpPut.addHeader("content-type", contentType);
		
		StringEntity entity = new StringEntity(jsonObj, ContentType.APPLICATION_JSON);
		httpPut.setEntity(entity);
		return httpPut;
		
	}
}